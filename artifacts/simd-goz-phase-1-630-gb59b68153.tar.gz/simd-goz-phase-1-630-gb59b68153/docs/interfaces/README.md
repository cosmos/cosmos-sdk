<!--
order: false
parent:
  order: 5
-->

# Interfaces

This repository contains documentation on interfaces for Cosmos SDK applications.

1. [Introduction to Interaces](./interfaces-intro.md)
2. [Lifecycle of a Query](./query-lifecycle.md)
3. [Command-Line Interface](./cli.md)
4. [Rest Interface](./rest.md)

