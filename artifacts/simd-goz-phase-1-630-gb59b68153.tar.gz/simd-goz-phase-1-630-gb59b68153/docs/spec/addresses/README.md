# Addresses spec

- [Bech32](./bech32.md)